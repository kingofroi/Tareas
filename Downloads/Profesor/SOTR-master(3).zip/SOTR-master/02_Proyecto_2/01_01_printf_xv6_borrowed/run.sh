#!/bin/sh
./$1 ;echo $? 
