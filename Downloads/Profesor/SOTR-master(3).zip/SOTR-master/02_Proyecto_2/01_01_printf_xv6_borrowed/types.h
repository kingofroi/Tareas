#ifndef _TYPES_H
#define _TYPES_H
typedef unsigned int	uint;



#endif /* _TYPES_H */
