#ifndef FECHATYPE_H
#define FECHATYPE_H
struct Fecha{
  int dia;
  int mes;
  int n;
  int *intPt;
};
typedef struct Fecha FechaType;
#endif /*FECHATYPE_H*/
