void salir();
long funcion(){
  int arr[]={3,67,44};
  salir(arr[0]);
}
