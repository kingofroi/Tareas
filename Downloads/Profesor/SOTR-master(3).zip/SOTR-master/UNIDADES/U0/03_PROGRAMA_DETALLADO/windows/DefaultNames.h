#ifndef DEFAULT_NAMES_
#define DEFAULT_NAMES_
void set_nombresdtemasdu1();
template <typename T>
class DefaultNames{
public:
  static T nombresdtemasdu1;
};

template <typename T>
T DefaultNames<T>::nombresdtemasdu1=(wchar_t**)0;
#endif /* DEFAULT_NAMES*/
