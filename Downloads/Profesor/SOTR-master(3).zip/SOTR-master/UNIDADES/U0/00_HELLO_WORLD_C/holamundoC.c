/*
 https://github.com/upiitacodelamberto/SOTR/
 UNIDADES/U0/
*/
/*#include <stdio.h>*/
void salir();

int main(){
  char msg[]="Hello  World!";
  char c=msg[0];



/*  printf("%s",p->que);*/
/*  getchar();*/

/*  return c;*/
    salir(c);
}/*end main()*/













