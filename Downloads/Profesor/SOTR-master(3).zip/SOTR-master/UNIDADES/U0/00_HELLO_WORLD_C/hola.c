extern int printf (const char *__restrict __format, ...);
void salir();
long main(){
  printf("SOTR\n");
  salir(0);
}
