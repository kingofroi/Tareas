/*
  TestPrintf.c - driver para usar la funcion
  void printf(int, char*, ...)
 */

int main(){
  char A[]="Las cosas que no se cumplieron de \"Volver al Futuro III\"\n";
  printf(1, A);
  return 0;
}
