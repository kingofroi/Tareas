#ifndef _IO_H
#define _IO_H

void
outb(unsigned short port, unsigned char data);

unsigned char
inb(unsigned short port);

#endif /* _IO_H */
