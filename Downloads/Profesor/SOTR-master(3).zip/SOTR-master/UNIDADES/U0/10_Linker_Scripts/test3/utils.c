#include "utils.h"

#if 0
void
printk(unsigned char lvl, unsigned const char *msg, ...)
{
	switch (lvl)
	{
	case KERN_INFO:
		break;

	case KERN_WARN:
		break;

	case KERN_ERROR:
		break;
	}
}
#endif

