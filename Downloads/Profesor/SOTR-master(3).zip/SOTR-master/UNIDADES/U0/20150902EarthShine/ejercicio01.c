int main(){
  printf("%s\n", diadlasemana(20150904));
  return 0;
}
/*
El programa debera imprimir Lunes, Martes, Miercoles, etc. segun 
el dia que corresponda a la fecha. La funcion debe funcionar bien 
para cualquier fecha de este mes (En el semestre actual, 
agosto-diciembre de 2015, Septiembre del anio 2015).
*/
