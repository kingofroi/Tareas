#include <stdio.h>
extern char variable[]; /*resuelto en nuevo1.asm*/
int main(){
//  char c=variable;
  printf("%s",variable);
  return 0;
}
