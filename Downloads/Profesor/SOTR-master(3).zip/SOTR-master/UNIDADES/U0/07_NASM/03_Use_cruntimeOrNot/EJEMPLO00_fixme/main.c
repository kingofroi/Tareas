void mymain(void)
{
  int a;
  a++;
}
